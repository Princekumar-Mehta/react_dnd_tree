import Item from "./Item";
import { useDrop } from "react-dnd";
import { ItemTypes } from "./itemTypes";

export default function Tree({ items, parent, move, find }) {
  const [{ isOver }, drop] = useDrop({
    accept: ItemTypes.ITEM,
    drop: (props, monitor) => {},
    hover: (props, monitor) => getMoving(props, monitor),
    collect: (monitor) => ({
      isOver: !!monitor.isOver()
    })
  });

  function getMoving(props, monitor) {
    if (!monitor.isOver({ shallow: true })) return;
    console.log(props, parent);
    const descendantNode = find(parent, props.children);
    if (descendantNode) return;
    if (props.parent === parent || props.id === parent) return;

    move(props.id, undefined, parent);
  }

  if (!items) return null;

  return (
    <div
      ref={drop}
      style={{
        position: "relative",
        minHeight: 10,
        paddingTop: 10,
        marginTop: -11,
        marginLeft: "2em",
        width: 300,
        backgroundColor: isOver ? "lightgreen" : "white"
      }}
    >
      {items.map((item, i) => {
        return (
          <Item
            key={item.id}
            id={item.id}
            parent={parent}
            item={item}
            move={move}
            find={find}
          />
        );
      })}
    </div>
  );
}
