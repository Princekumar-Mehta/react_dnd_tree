import { useState } from "react";
import "./styles.css";
import Tree from "./Tree";

/**
 *
 * ADOPTED FROM HERE
 * https://github.com/tamagokun/example-react-dnd-nested
 *
 */

export default function App() {
  const [tree, setTree] = useState([
    {
      id: 1,
      title: "Tatooine",
      children: [
        { id: 2, title: "Endor", children: [] },
        { id: 3, title: "Hoth", children: [] },
        { id: 4, title: "Dagobah", children: [] }
      ]
    },
    {
      id: 5,
      title: "Death Star",
      children: []
    },
    {
      id: 6,
      title: "Alderaan",
      children: [
        {
          id: 7,
          title: "Bespin",
          children: [{ id: 8, title: "Jakku", children: [] }]
        }
      ]
    }
  ]);

  function moveItem(id, afterId, nodeId) {
    if (id === afterId) return;

    let cloneTree = [...tree];

    const removeNode = (id, items) => {
      for (const node of items) {
        if (node.id === id) {
          items.splice(items.indexOf(node), 1);
          return;
        }

        if (node.children && node.children.length) {
          removeNode(id, node.children);
        }
      }
    };

    const item = { ...findItem(id, cloneTree) };
    if (!item.id) {
      return;
    }

    const destination = nodeId
      ? findItem(nodeId, cloneTree).children
      : cloneTree;

    if (!afterId) {
      removeNode(id, cloneTree);
      destination.push(item);
    } else {
      const index = destination.indexOf(
        destination
          .filter((destinationItem) => destinationItem.id === afterId)
          .shift()
      );
      removeNode(id, cloneTree);
      destination.splice(index, 0, item);
    }

    setTree(cloneTree);
  }

  function findItem(id, items) {
    if (!items) return;
    for (const node of items) {
      if (node.id === id) return node;
      if (node.children && node.children.length) {
        const result = findItem(id, node.children);
        if (result) {
          return result;
        }
      }
    }

    return false;
  }

  return (
    <div className="App">
      <Tree parent={null} items={tree} move={moveItem} find={findItem} />
    </div>
  );
}
