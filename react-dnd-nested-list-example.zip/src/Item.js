import Tree from "./Tree";
import { ItemTypes } from "./itemTypes";
import { useDrag, useDrop } from "react-dnd";

export default function Item({ parent, item, move, find }) {
  const [, drop] = useDrop({
    accept: ItemTypes.ITEM,
    canDrop: false,
    hover: (draggedItem, monitor) => {
      if (draggedItem.id === item.id || draggedItem.id === parent) return;
      if (!monitor.isOver({ shallow: true })) return;

      move(draggedItem.id, item.id, parent);
    }
  });

  const [, drag, preview] = useDrag({
    type: ItemTypes.ITEM,
    item: {
      id: item.id,
      parent,
      children: item.children
    },
    isDragging: (monitor) => item.id === monitor.getItem().id
  });

  return (
    <div ref={drop}>
      <div ref={preview}>
        <div
          ref={drag}
          style={{
            background: "#f5f5f5",
            border: "1px solid #ccc",
            padding: "1em",
            marginBottom: -1
          }}
        >
          {item.title}
        </div>
        <Tree parent={item.id} items={item.children} move={move} find={find} />
      </div>
    </div>
  );
}
